package com.metasploit.stage;
import android.app.*;
import android.content.*;
import android.os.*;

public class MainService extends Service
{

	@Override
	public IBinder onBind(Intent p1)
	{
		// TODO: Implement this method
		return null;
	}


	public static void startService(Context service)
	{
		// TODO: Implement this method
		
	}
	
}
