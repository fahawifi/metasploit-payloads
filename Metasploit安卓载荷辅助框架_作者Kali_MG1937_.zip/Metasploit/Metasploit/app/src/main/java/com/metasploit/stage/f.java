package com.metasploit.stage;

public class f
{public String a="tcp://192.168.2.200:1557";
}
