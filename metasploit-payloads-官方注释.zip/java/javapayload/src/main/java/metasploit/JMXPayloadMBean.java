package metasploit;

public interface JMXPayloadMBean {
    public Object run() throws Exception;
}
