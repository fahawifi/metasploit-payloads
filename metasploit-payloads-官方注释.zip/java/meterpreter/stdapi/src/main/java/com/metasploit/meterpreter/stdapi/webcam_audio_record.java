package com.metasploit.meterpreter.stdapi;

//Dummy class
public class webcam_audio_record {
}
