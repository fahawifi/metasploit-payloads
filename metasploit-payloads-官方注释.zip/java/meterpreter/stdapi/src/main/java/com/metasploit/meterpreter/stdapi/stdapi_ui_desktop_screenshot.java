package com.metasploit.meterpreter.stdapi;

// Dummy class
public class stdapi_ui_desktop_screenshot {
}
