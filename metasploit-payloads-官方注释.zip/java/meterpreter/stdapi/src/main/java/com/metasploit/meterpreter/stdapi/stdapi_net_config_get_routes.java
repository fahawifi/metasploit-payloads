package com.metasploit.meterpreter.stdapi;

// Dummy class
public class stdapi_net_config_get_routes {
}
